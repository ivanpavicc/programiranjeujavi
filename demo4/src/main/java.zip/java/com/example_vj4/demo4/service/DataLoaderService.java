package com.example_vj4.demo4.service;

import com.example_vj4.demo4.model.Book;
import com.example_vj4.demo4.repository.BookRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.io.InputStream;
import java.util.List;

@Service
public class DataLoaderService {

    private final BookRepository bookRepository;

    public DataLoaderService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @PostConstruct
    public void loadBooks() {
        try {
            // Provjera je li baza već popunjena
            if (bookRepository.count() > 0) {
                System.out.println("Podaci su već učitani u bazu. Preskače se učitavanje.");
                return;
            }

            // Učitavanje JSON datoteke
            ObjectMapper objectMapper = new ObjectMapper();
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("books.json");

            if (inputStream == null) {
                System.err.println("Datoteka books.json nije pronađena u resursima.");
                return;
            }

            List<Book> books = objectMapper.readValue(inputStream, new TypeReference<List<Book>>() {});

            // Spremanje knjiga u bazu podataka
            bookRepository.saveAll(books);
            System.out.println("Podaci su uspješno učitani iz books.json u bazu podataka.");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Došlo je do greške prilikom učitavanja podataka iz books.json.");
        }
    }
}
