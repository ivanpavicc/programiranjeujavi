package com.example_vj4.demo4.service;

import com.example_vj4.demo4.model.Book;
import com.example_vj4.demo4.repository.BookRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Dohvaća sve knjige
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    // Dohvaća knjigu prema ID-u
    public Book getBookById(Long id) {
        return bookRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Book not found with id: " + id));
    }

    // Sprema novu knjigu
    public Book saveBook(Book book) {
        return bookRepository.save(book);
    }

    // Briše knjigu prema ID-u
    public void deleteBook(Long id) {
        bookRepository.deleteById(id);
    }

    // Dohvaća knjige s filtriranjem i paginacijom
    public Page<Book> getBooks(String title, String author, String genre, Integer publicationYear, Pageable pageable) {
        if (pageable == null) {
            pageable = PageRequest.of(0, 10); // Zadana paginacija ako nije specificirana
        }
        return bookRepository.findAll(pageable); // Trenutno vraća sve bez filtriranja (prilagoditi prema potrebi)
    }
}
